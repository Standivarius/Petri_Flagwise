# Pinecone Assistant → Petri Wrapper

OpenAI-compatible HTTP shim that allows Petri (Inspect AI) to test Pinecone assistants.

## Quick Start

1. **Extract archive**:
   ```bash
   tar -xzf pinecone-petri-wrapper.tar.gz
   cd pinecone-petri-wrapper
   ```

2. **Configure**:
   ```bash
   cp ops/.env.example wrapper/.env
   nano wrapper/.env  # Fill in Pinecone credentials
   ```

3. **Deploy** (choose one):

   **Docker** (recommended for VPS):
   ```bash
   cd wrapper
   docker-compose up -d
   ```

   **Python venv** (alternative):
   ```bash
   cd wrapper
   python3 -m venv venv
   venv/bin/pip install -r requirements.txt
   venv/bin/python main.py
   ```

4. **Test**:
   ```bash
   # Local smoke
   cd tests
   ./curl_smoke.sh 8080 your-wrapper-token

   # Petri smoke
   export OPENAI_BASE_URL=http://localhost:8080/v1
   export OPENAI_API_KEY=your-wrapper-token
   export ANTHROPIC_API_KEY=sk-ant-...
   cd petri_smoke
   ./run_petri_smoke.sh
   ```

## What's Inside

```
pinecone-petri-wrapper/
├── wrapper/              # Core service
│   ├── main.py          # FastAPI app (OpenAI-compatible)
│   ├── config.py        # Environment config
│   ├── models.py        # Pydantic models
│   ├── requirements.txt
│   ├── Dockerfile
│   └── docker-compose.yml
├── ops/                 # Deployment files
│   ├── .env.example    # Config template
│   └── pinecone-wrapper.service  # systemd unit
├── tests/              # Smoke tests
│   ├── curl_smoke.sh   # Local HTTP test
│   └── petri_smoke/    # Petri eval test
│       ├── minimal_eval.py
│       └── run_petri_smoke.sh
├── RUNBOOK.md          # ⭐ Complete deployment guide
└── README.md           # This file
```

## Key Features

✅ OpenAI `/v1/chat/completions` compatible
✅ Health endpoint at `/healthz`
✅ Request logging with secret redaction
✅ Timeouts and retries (configurable)
✅ Docker + systemd deployment options
✅ Production-grade error handling

## Architecture

```
Petri/Inspect ──OPENAI_BASE_URL──> Wrapper ──Pinecone API──> Assistant
      │                               │
   (thinks it's                  (translates
    OpenAI API)                  OpenAI ⟷ Pinecone)
```

## Environment Variables

**Required**:
- `ASSISTANT_BASE_URL` - Pinecone API endpoint
- `PINECONE_API_KEY` - Your API key
- `WRAPPER_TOKEN` - Auth for wrapper (generate with `openssl rand -hex 32`)

**Optional**:
- `ASSISTANT_ID`, `INDEX`, `PROJECT` - Pinecone identifiers
- `PORT=8080` - Bind port
- `BIND_HOST=127.0.0.1` - Bind address
- `UPSTREAM_TIMEOUT=30.0` - Pinecone timeout
- `MAX_RETRIES=1` - Retry attempts

See `ops/.env.example` for full list.

## Deployment Paths

### Path 1: Docker (Recommended)

```bash
cd wrapper
cp ../ops/.env.example .env
nano .env  # Configure
docker-compose up -d
```

**Pros**: Isolated, reproducible, easy to manage
**Cons**: Requires Docker

### Path 2: Venv + Systemd

```bash
sudo mkdir /opt/pinecone-wrapper
sudo cp wrapper/* /opt/pinecone-wrapper/
cd /opt/pinecone-wrapper
sudo python3 -m venv venv
sudo venv/bin/pip install -r requirements.txt
sudo cp ../ops/.env.example .env
sudo nano .env  # Configure
sudo cp ../ops/pinecone-wrapper.service /etc/systemd/system/
sudo systemctl enable --now pinecone-wrapper
```

**Pros**: No Docker needed, native systemd
**Cons**: More manual setup

## Testing

### 1. Health Check (5 seconds)

```bash
curl http://localhost:8080/healthz
# {"status":"healthy","service":"pinecone-petri-wrapper"}
```

### 2. Local Smoke (30 seconds)

```bash
cd tests
./curl_smoke.sh 8080 your-wrapper-token
```

**Validates**:
- Wrapper responds to HTTP requests
- OpenAI format translation works
- Pinecone assistant returns responses

### 3. Petri Smoke (60 seconds, costs ~$0.02)

```bash
export OPENAI_BASE_URL=http://localhost:8080/v1
export OPENAI_API_KEY=your-wrapper-token
export ANTHROPIC_API_KEY=sk-ant-...
cd tests/petri_smoke
./run_petri_smoke.sh
```

**Validates**:
- Petri can call wrapper as OpenAI model
- Multi-turn conversation works
- Judge can score responses
- Logs are generated correctly

## Troubleshooting

### "Connection refused"

- Wrapper not started: `docker-compose ps` or `systemctl status pinecone-wrapper`
- Wrong port: Check `PORT` in `.env`

### "401 Unauthorized"

- Wrong `WRAPPER_TOKEN`: Must match between `.env` and request
- Missing `Authorization: Bearer` header

### "504 Timeout"

- Pinecone is slow: Increase `UPSTREAM_TIMEOUT` in `.env`
- Network issues: Check connectivity to Pinecone

### "Cannot parse Pinecone response"

- API format changed: Adjust `main.py` lines 175-195
- See RUNBOOK.md → Troubleshooting → Pinecone API Format Mismatch

## Documentation

- **RUNBOOK.md** - Complete deployment and troubleshooting guide (⭐ READ THIS FIRST)
- **ops/.env.example** - All configuration options
- **wrapper/main.py** - Code comments explain API translation

## Cost Estimate

**Per Petri smoke test**:
- Target model (Pinecone): ~100-200 tokens (usually free tier)
- Judge model (Claude): ~500-1000 tokens (~$0.01-0.02)
- **Total**: < $0.05

**For a real audit campaign** (100+ scenarios):
- Target model: Depends on Pinecone pricing
- Judge model: ~$5-20 depending on scenarios

## Next Steps

1. ✅ Extract archive
2. ✅ Read RUNBOOK.md (especially "Option A vs B" and "Environment Variables")
3. ✅ Configure `.env` file
4. ✅ Deploy with Docker or systemd
5. ✅ Run `curl_smoke.sh` to verify wrapper works
6. ✅ Run `run_petri_smoke.sh` to verify Petri integration
7. 🚀 Build your own Petri evals using Pinecone assistant

## Support

- **Runbook**: See RUNBOOK.md for detailed troubleshooting
- **Logs**: `docker-compose logs` or `journalctl -u pinecone-wrapper`
- **Health**: `curl http://localhost:8080/healthz`

## License

MIT (adjust as needed)

## Version

**Wrapper**: 1.0.0
**Runbook**: 1.0.0
**Date**: 2025-11-13
