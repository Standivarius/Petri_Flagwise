# Pinecone Assistant → Petri Wrapper: Runbook

## Quick Navigation

- [Option A vs B](#option-a-vs-b-chosen--rationale)
- [Environment Variables](#environment-variables)
- [Docker Deployment](#docker-deployment)
- [Venv + Systemd Deployment](#venv--systemd-deployment)
- [Local Smoke Test](#local-smoke-test-curl)
- [Petri Smoke Test](#petri-smoke-test)
- [Troubleshooting](#troubleshooting)

---

## Option A vs B: Chosen & Rationale

**✅ OPTION A CHOSEN: OpenAI-Compatible HTTP Shim**

### Rationale

1. **Native Petri/Inspect Support**: Inspect AI has built-in support for OpenAI providers via `OPENAI_BASE_URL` and `OPENAI_API_KEY` environment variables
2. **Well-Documented Interface**: OpenAI's `/v1/chat/completions` is the de facto standard for LLM APIs
3. **Zero Inspect Internals**: No need to understand Inspect's model provider internals or write custom adapters
4. **Battle-Tested**: Same interface used by thousands of tools in the LLM ecosystem
5. **Simple Switching**: Change `OPENAI_BASE_URL` to point at any OpenAI-compatible endpoint

### How to Use

Point Petri at the wrapper by setting these environment variables before running `inspect eval`:

```bash
export OPENAI_BASE_URL=http://localhost:8080/v1
export OPENAI_API_KEY=your-wrapper-token
```

Then run eval normally:

```bash
inspect eval your_eval.py --model openai/gpt-4
```

### Switching to Option B (Not Implemented)

If you need a native Inspect model provider:

1. Create a custom `ModelAPI` subclass in Inspect
2. Implement `generate()` method to call Pinecone
3. Register with `@modelapi` decorator
4. Use `--model pinecone/assistant-name` instead

This adds complexity with minimal benefit for smoke testing.

---

## Environment Variables

### Required

| Variable | Description | Example |
|----------|-------------|---------|
| `ASSISTANT_BASE_URL` | Pinecone Assistant API endpoint | `https://api.pinecone.io/assistant` |
| `PINECONE_API_KEY` | Your Pinecone API key | `pc-abc123...` |
| `WRAPPER_TOKEN` | Auth token for wrapper (generate securely) | `a1b2c3d4...` (use `openssl rand -hex 32`) |

### Optional

| Variable | Description | Default |
|----------|-------------|---------|
| `ASSISTANT_ID` | Pinecone assistant identifier | `null` |
| `INDEX` | Pinecone index name | `null` |
| `PROJECT` | Pinecone project ID | `null` |
| `PORT` | Port to bind wrapper | `8080` |
| `BIND_HOST` | Host to bind (localhost or 0.0.0.0) | `127.0.0.1` |
| `CONNECT_TIMEOUT` | Connection timeout (seconds) | `10.0` |
| `UPSTREAM_TIMEOUT` | Request timeout to Pinecone (seconds) | `30.0` |
| `MAX_RETRIES` | Retry attempts for 502/503 | `1` |

### Example .env File

See `ops/.env.example`:

```bash
ASSISTANT_BASE_URL=https://api.pinecone.io/assistant
PINECONE_API_KEY=your-actual-api-key
WRAPPER_TOKEN=$(openssl rand -hex 32)
PORT=8080
BIND_HOST=127.0.0.1
```

---

## Docker Deployment

### Prerequisites

- Docker and Docker Compose installed
- `.env` file configured (copy from `ops/.env.example`)

### Steps

1. **Copy archive to VPS**:

```bash
# On laptop
scp pinecone-petri-wrapper.tar.gz user@your-vps:/tmp/

# SSH to VPS
ssh user@your-vps
```

2. **Extract and setup**:

```bash
cd /tmp
tar -xzf pinecone-petri-wrapper.tar.gz
cd pinecone-petri-wrapper/wrapper
```

3. **Create .env file**:

```bash
cp ../ops/.env.example .env
nano .env  # Fill in your actual values
```

**Important**: Set these at minimum:
- `ASSISTANT_BASE_URL`
- `PINECONE_API_KEY`
- `WRAPPER_TOKEN` (generate with `openssl rand -hex 32`)

4. **Build and start**:

```bash
docker-compose build
docker-compose up -d
```

5. **Verify health**:

```bash
curl http://localhost:8080/healthz
# Should return: {"status":"healthy","service":"pinecone-petri-wrapper"}
```

6. **Check logs**:

```bash
docker-compose logs -f
```

### Docker Management

```bash
# View status
docker-compose ps

# Stop
docker-compose down

# Restart
docker-compose restart

# View logs (last 100 lines)
docker-compose logs --tail=100

# Follow logs
docker-compose logs -f
```

---

## Venv + Systemd Deployment

### Prerequisites

- Python 3.11+
- systemd-based Linux (Ubuntu/Debian)
- Root or sudo access

### Steps

1. **Copy archive to VPS** (same as Docker)

2. **Extract and install**:

```bash
sudo mkdir -p /opt/pinecone-wrapper
cd /tmp/pinecone-petri-wrapper/wrapper
sudo cp -r * /opt/pinecone-wrapper/
cd /opt/pinecone-wrapper
```

3. **Create virtual environment**:

```bash
sudo python3 -m venv venv
sudo venv/bin/pip install -r requirements.txt
```

4. **Create .env file**:

```bash
sudo cp /tmp/pinecone-petri-wrapper/ops/.env.example /opt/pinecone-wrapper/.env
sudo nano /opt/pinecone-wrapper/.env  # Fill in values
```

5. **Set permissions**:

```bash
sudo chown -R ubuntu:ubuntu /opt/pinecone-wrapper
sudo chmod 600 /opt/pinecone-wrapper/.env
```

6. **Install systemd service**:

```bash
sudo cp /tmp/pinecone-petri-wrapper/ops/pinecone-wrapper.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable pinecone-wrapper
sudo systemctl start pinecone-wrapper
```

7. **Verify**:

```bash
sudo systemctl status pinecone-wrapper
curl http://localhost:8080/healthz
```

### Systemd Management

```bash
# Status
sudo systemctl status pinecone-wrapper

# Logs
sudo journalctl -u pinecone-wrapper -f

# Restart
sudo systemctl restart pinecone-wrapper

# Stop
sudo systemctl stop pinecone-wrapper

# Disable
sudo systemctl disable pinecone-wrapper
```

---

## Local Smoke Test (curl)

### Prerequisites

- Wrapper running (Docker or systemd)
- `jq` installed (`sudo apt install jq`)

### Run Test

```bash
cd tests
chmod +x curl_smoke.sh

# Replace with your actual wrapper token
./curl_smoke.sh 8080 your-wrapper-token
```

### Expected Output

```
=== Pinecone Wrapper Smoke Test ===
Base URL: http://localhost:8080

[1/3] Testing health endpoint...
✅ Health check passed: {"status":"healthy","service":"pinecone-petri-wrapper"}

[2/3] Testing root endpoint...
✅ Root endpoint: {"service":"Pinecone Assistant → OpenAI Wrapper","version":"1.0.0",...}

[3/3] Testing chat completion endpoint...
Request payload:
{
  "model": "pinecone-assistant",
  "messages": [...]
}

✅ Chat completion successful!

Full response:
{
  "id": "chatcmpl-abc123",
  "object": "chat.completion",
  "created": 1234567890,
  "model": "pinecone-assistant",
  "choices": [{
    "index": 0,
    "message": {
      "role": "assistant",
      "content": "Hello! I'm happy to help you today..."
    },
    "finish_reason": "stop"
  }],
  "usage": {...}
}

Assistant message:
Hello! I'm happy to help you today...

=== All tests passed! ===
```

### Pass Criteria

✅ Health check returns 200 within 100ms
✅ Chat completion returns 200 with assistant message
✅ Assistant message content is coherent (not a stub/error)

---

## Petri Smoke Test

### Prerequisites

- Wrapper running and curl smoke test passed
- Petri/Inspect AI installed (`pip install inspect-ai`)
- Anthropic API key for judge model

### Setup Environment

```bash
# Point Petri at the wrapper
export OPENAI_BASE_URL=http://localhost:8080/v1
export OPENAI_API_KEY=your-wrapper-token

# Set judge model API key
export ANTHROPIC_API_KEY=sk-ant-your-key-here
```

### Run Test

```bash
cd tests/petri_smoke
chmod +x run_petri_smoke.sh
./run_petri_smoke.sh
```

### Manual Command (if script fails)

```bash
cd tests/petri_smoke

inspect eval minimal_eval.py@pinecone_smoke \
    --model openai/gpt-4 \
    --log-dir ./smoke_logs
```

**Note**: We use `--model openai/gpt-4` but Inspect will actually call the wrapper at `$OPENAI_BASE_URL` instead of real OpenAI.

### Expected Output

```
=== Petri Smoke Test ===

✅ Environment configured:
   Target: http://localhost:8080/v1
   Wrapper token: a1b2c3d4e5...
   Judge: Anthropic Claude

Running Petri eval (this will take ~30-60 seconds)...

[Inspect output showing eval progress...]

=== Petri Smoke Test Complete ===

✅ Logs written to: ./smoke_logs
   Latest log: smoke_logs/2025-11-13T12-34-56_pinecone_smoke.json

View results with: inspect view
Or check the JSON: cat smoke_logs/2025-11-13T12-34-56_pinecone_smoke.json | jq '.results'
```

### Pass Criteria

✅ Eval completes without errors
✅ Transcript file created in `smoke_logs/`
✅ Transcript contains:
  - System message
  - User message: "What is 2+2?"
  - Assistant message from Pinecone (should answer "4")
✅ Judge scores are present in results

### View Results

```bash
# View with Inspect viewer
inspect view

# Or examine JSON directly
cd smoke_logs
cat *.json | jq '.results.scores'
```

### Cost Estimate

- **Target model**: 1-2 turns, ~100-200 tokens (negligible on Pinecone)
- **Judge model**: ~500-1000 tokens for scoring (~$0.01-0.02)
- **Total**: < $0.05 per smoke test

---

## Troubleshooting

### Bad Credentials

**Symptom**: `401 Unauthorized` or `Invalid authentication token`

**Causes**:

1. Wrapper token mismatch
2. Pinecone API key invalid

**Debug**:

```bash
# Test wrapper auth
curl -H "Authorization: Bearer wrong-token" http://localhost:8080/healthz
# Should return 401

curl -H "Authorization: Bearer correct-token" http://localhost:8080/healthz
# Should return 200

# Check Pinecone credentials
# Look at wrapper logs for errors when calling Pinecone
docker-compose logs | grep "Pinecone"
```

**Fix**:

- Ensure `WRAPPER_TOKEN` in `.env` matches the token you use in requests
- Verify `PINECONE_API_KEY` is correct
- Restart wrapper after changing `.env`

---

### CORS / Bind Issues

**Symptom**: Cannot access wrapper from remote machine

**Cause**: Wrapper bound to `127.0.0.1` (localhost only)

**Fix**:

```bash
# In .env, change:
BIND_HOST=0.0.0.0

# Restart
docker-compose restart
```

**Security Note**: Only bind to `0.0.0.0` if needed. Use firewall rules to restrict access.

---

### Timeout Errors

**Symptom**: `504 Gateway Timeout` or `Pinecone Assistant timeout`

**Causes**:

1. Pinecone API is slow/overloaded
2. Timeout settings too aggressive

**Debug**:

```bash
# Check wrapper logs for timing
docker-compose logs | grep "Pinecone responded"
# Look for: "Pinecone responded in 25.5s"
```

**Fix**:

```bash
# In .env, increase timeouts:
UPSTREAM_TIMEOUT=60.0
CONNECT_TIMEOUT=15.0

# Restart
docker-compose restart
```

---

### 4xx/5xx Mapping

**Symptom**: Pinecone returns 400/500, Petri sees wrong error

**Understanding**:

Wrapper maps Pinecone errors to OpenAI-compatible format:

| Pinecone Code | Wrapper Code | Retry? |
|---------------|--------------|--------|
| 400 Bad Request | 400 | No |
| 401 Unauthorized | 401 | No |
| 404 Not Found | 404 | No |
| 429 Rate Limit | 429 | No |
| 500 Internal | 500 | No |
| 502 Bad Gateway | 502 | **Yes** (exponential backoff) |
| 503 Service Unavailable | 503 | **Yes** (exponential backoff) |
| 504 Timeout | 504 | No |

**Debug**:

```bash
# Check wrapper logs for Pinecone errors
docker-compose logs | grep "Pinecone error"
```

**Fix**:

- **400-level errors**: Check your Pinecone request format (may need to adjust `main.py` line 150-160)
- **500-level errors**: Wait for Pinecone to recover, or increase retries
- **Retries**: Set `MAX_RETRIES=3` in `.env` for more aggressive retry

---

### Pinecone API Format Mismatch

**Symptom**: Wrapper sends request but Pinecone rejects it, or response cannot be parsed

**Cause**: The wrapper assumes a specific Pinecone API format which may differ from actual

**Debug**:

1. Check wrapper logs for request/response:

```bash
docker-compose logs | grep "Calling Pinecone"
```

2. Test Pinecone API directly:

```bash
curl -X POST https://your-pinecone-api/chat \
  -H "Api-Key: your-key" \
  -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"test"}]}'
```

**Fix**:

Adjust `main.py` based on actual Pinecone API:

- **Line 110-135**: Pinecone request format (payload structure)
- **Line 175-195**: Pinecone response parsing (extract assistant message)

Common variations:

```python
# If Pinecone uses "query" instead of "messages":
payload = {"query": messages[-1]["content"]}

# If response is in "answer" field:
assistant_message = pinecone_response.get("answer", "")

# If assistant_id goes in URL path:
url = f"{settings.ASSISTANT_BASE_URL}/assistants/{settings.ASSISTANT_ID}/chat"
```

---

### Health Check Fails

**Symptom**: `/healthz` returns 500 or times out

**Causes**:

1. Wrapper not started
2. Port mismatch
3. Python errors on startup

**Debug**:

```bash
# Check if process is running
docker-compose ps
# OR
sudo systemctl status pinecone-wrapper

# Check logs for startup errors
docker-compose logs
# OR
sudo journalctl -u pinecone-wrapper --no-pager

# Test direct connection
curl -v http://localhost:8080/healthz
```

**Fix**:

- Ensure `.env` is properly configured (run `settings.validate()` check)
- Check Python dependencies are installed
- Verify port is not in use: `sudo lsof -i :8080`

---

### Petri Cannot Connect to Wrapper

**Symptom**: `inspect eval` fails with "Connection refused" or "Cannot connect to model"

**Causes**:

1. `OPENAI_BASE_URL` not set or wrong
2. Wrapper not running
3. Network/firewall blocking connection

**Debug**:

```bash
# Verify env vars
echo $OPENAI_BASE_URL
echo $OPENAI_API_KEY

# Test connectivity
curl -H "Authorization: Bearer $OPENAI_API_KEY" \
     $OPENAI_BASE_URL/../../healthz

# Check wrapper status
docker-compose ps
```

**Fix**:

```bash
# Ensure variables are exported (not just set)
export OPENAI_BASE_URL=http://localhost:8080/v1
export OPENAI_API_KEY=your-token

# Verify wrapper is up
curl http://localhost:8080/healthz

# Re-run Petri
inspect eval minimal_eval.py@pinecone_smoke --model openai/gpt-4
```

---

### No Transcript Generated

**Symptom**: Petri eval runs but no transcript in `smoke_logs/`

**Causes**:

1. Eval failed silently
2. Log directory permissions
3. Inspect not writing logs

**Debug**:

```bash
# Check for errors in Inspect output
inspect eval minimal_eval.py@pinecone_smoke --model openai/gpt-4 2>&1 | tee eval.log

# Check log directory exists and is writable
ls -la tests/petri_smoke/smoke_logs/

# Run with verbose logging
inspect eval minimal_eval.py@pinecone_smoke --model openai/gpt-4 --log-level debug
```

**Fix**:

- Ensure `--log-dir ./smoke_logs` is specified
- Create directory manually: `mkdir -p tests/petri_smoke/smoke_logs`
- Check Inspect AI version: `pip show inspect-ai` (needs 0.3+)

---

## Quick Reference Commands

### Docker Deployment

```bash
# Start
docker-compose up -d

# Stop
docker-compose down

# Logs
docker-compose logs -f

# Health
curl http://localhost:8080/healthz
```

### Systemd Deployment

```bash
# Start
sudo systemctl start pinecone-wrapper

# Stop
sudo systemctl stop pinecone-wrapper

# Logs
sudo journalctl -u pinecone-wrapper -f

# Health
curl http://localhost:8080/healthz
```

### Petri Smoke Test

```bash
# Setup
export OPENAI_BASE_URL=http://localhost:8080/v1
export OPENAI_API_KEY=your-wrapper-token
export ANTHROPIC_API_KEY=sk-ant-...

# Run
cd tests/petri_smoke
./run_petri_smoke.sh

# View results
inspect view
```

---

## Advanced: Production Deployment

For production use beyond smoke testing:

1. **TLS/HTTPS**: Put wrapper behind nginx with Let's Encrypt
2. **Rate Limiting**: Add nginx rate limits or API gateway
3. **Monitoring**: Add Prometheus metrics endpoint
4. **Logging**: Ship logs to centralized system (ELK, Loki)
5. **Secrets**: Use secrets manager instead of `.env` file
6. **Scaling**: Run multiple wrapper instances behind load balancer

See `docs/PRODUCTION.md` (not included in smoke test archive).

---

## Support

For issues:

1. Check this runbook's troubleshooting section
2. Review wrapper logs for errors
3. Test Pinecone API directly to isolate wrapper issues
4. Verify Inspect AI version compatibility
5. Check Pinecone API documentation for format changes

---

**Runbook Version**: 1.0.0
**Last Updated**: 2025-11-13
**Wrapper Version**: 1.0.0
**Inspect AI Version**: 0.3+
