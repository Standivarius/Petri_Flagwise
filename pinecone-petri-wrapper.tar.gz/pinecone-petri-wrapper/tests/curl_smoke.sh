#!/bin/bash
# Local smoke test for Pinecone wrapper
# Usage: ./curl_smoke.sh [PORT] [WRAPPER_TOKEN]

set -e

PORT="${1:-8080}"
WRAPPER_TOKEN="${2:-your-wrapper-token}"
BASE_URL="http://localhost:${PORT}"

echo "=== Pinecone Wrapper Smoke Test ==="
echo "Base URL: $BASE_URL"
echo ""

# Test 1: Health check
echo "[1/3] Testing health endpoint..."
HEALTH_RESPONSE=$(curl -s -w "\n%{http_code}" "${BASE_URL}/healthz")
HEALTH_CODE=$(echo "$HEALTH_RESPONSE" | tail -n1)
HEALTH_BODY=$(echo "$HEALTH_RESPONSE" | head -n-1)

if [ "$HEALTH_CODE" = "200" ]; then
    echo "✅ Health check passed: $HEALTH_BODY"
else
    echo "❌ Health check failed with code $HEALTH_CODE"
    exit 1
fi
echo ""

# Test 2: Root endpoint
echo "[2/3] Testing root endpoint..."
ROOT_RESPONSE=$(curl -s "${BASE_URL}/")
echo "✅ Root endpoint: $ROOT_RESPONSE"
echo ""

# Test 3: Chat completion
echo "[3/3] Testing chat completion endpoint..."
CHAT_REQUEST='{
  "model": "pinecone-assistant",
  "messages": [
    {
      "role": "system",
      "content": "You are a helpful assistant."
    },
    {
      "role": "user",
      "content": "Hello! Please respond with a brief greeting."
    }
  ]
}'

echo "Request payload:"
echo "$CHAT_REQUEST" | jq '.'
echo ""

CHAT_RESPONSE=$(curl -s -w "\n%{http_code}" \
    -X POST "${BASE_URL}/v1/chat/completions" \
    -H "Authorization: Bearer ${WRAPPER_TOKEN}" \
    -H "Content-Type: application/json" \
    -d "$CHAT_REQUEST")

CHAT_CODE=$(echo "$CHAT_RESPONSE" | tail -n1)
CHAT_BODY=$(echo "$CHAT_RESPONSE" | head -n-1)

if [ "$CHAT_CODE" = "200" ]; then
    echo "✅ Chat completion successful!"
    echo ""
    echo "Full response:"
    echo "$CHAT_BODY" | jq '.'
    echo ""
    echo "Assistant message:"
    echo "$CHAT_BODY" | jq -r '.choices[0].message.content'
else
    echo "❌ Chat completion failed with code $CHAT_CODE"
    echo "Response: $CHAT_BODY"
    exit 1
fi

echo ""
echo "=== All tests passed! ==="
echo ""
echo "Next steps:"
echo "1. Verify the assistant message looks correct"
echo "2. Run Petri smoke test: cd tests/petri_smoke && bash run_petri_smoke.sh"
