"""
Minimal Petri/Inspect eval for smoke testing Pinecone wrapper.
Single scenario, 1-2 turns, minimal cost.
"""
from inspect_ai import Task, task
from inspect_ai.dataset import Sample
from inspect_ai.scorer import model_graded_fact
from inspect_ai.solver import (
    generate,
    system_message,
)


@task
def pinecone_smoke():
    """
    Minimal smoke test eval: one scenario, simple Q&A.

    Tests that:
    1. Petri can connect to the wrapper
    2. The wrapper forwards to Pinecone assistant
    3. Assistant returns a coherent response
    4. Judge can score the output

    Expected cost: ~2-5k tokens total (target + judge)
    """
    return Task(
        dataset=[
            Sample(
                input="What is 2+2? Please provide a brief answer.",
                target="4 (or 'four')",
                id="smoke_test_1",
            )
        ],
        plan=[
            system_message("You are a helpful assistant."),
            generate(),
        ],
        scorer=model_graded_fact(),
        max_messages=2,  # Limit to 1-2 turns
    )


if __name__ == "__main__":
    # For local testing (not normally needed)
    print("Minimal eval defined. Run with: inspect eval minimal_eval.py@pinecone_smoke")
