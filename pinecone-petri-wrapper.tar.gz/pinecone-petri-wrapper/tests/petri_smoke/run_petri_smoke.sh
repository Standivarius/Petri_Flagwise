#!/bin/bash
# Petri smoke test for Pinecone wrapper
# Run this after starting the wrapper service
#
# Prerequisites:
# - Wrapper running on localhost:${PORT}
# - OPENAI_BASE_URL and OPENAI_API_KEY env vars set
# - Judge model API key set (ANTHROPIC_API_KEY)
#
# Usage:
#   export OPENAI_BASE_URL=http://localhost:8080/v1
#   export OPENAI_API_KEY=your-wrapper-token
#   export ANTHROPIC_API_KEY=your-anthropic-key
#   bash run_petri_smoke.sh

set -e

echo "=== Petri Smoke Test ==="
echo ""

# Check required env vars
if [ -z "$OPENAI_BASE_URL" ]; then
    echo "❌ OPENAI_BASE_URL not set"
    echo "   Set with: export OPENAI_BASE_URL=http://localhost:8080/v1"
    exit 1
fi

if [ -z "$OPENAI_API_KEY" ]; then
    echo "❌ OPENAI_API_KEY not set (wrapper token)"
    echo "   Set with: export OPENAI_API_KEY=your-wrapper-token"
    exit 1
fi

if [ -z "$ANTHROPIC_API_KEY" ]; then
    echo "❌ ANTHROPIC_API_KEY not set (for judge)"
    echo "   Set with: export ANTHROPIC_API_KEY=sk-ant-..."
    exit 1
fi

echo "✅ Environment configured:"
echo "   Target: $OPENAI_BASE_URL"
echo "   Wrapper token: ${OPENAI_API_KEY:0:10}..."
echo "   Judge: Anthropic Claude"
echo ""

# Run Petri eval
echo "Running Petri eval (this will take ~30-60 seconds)..."
echo ""

inspect eval minimal_eval.py@pinecone_smoke \
    --model openai/gpt-4 \
    --log-dir ./smoke_logs

echo ""
echo "=== Petri Smoke Test Complete ==="
echo ""

# Check for results
if [ -d "./smoke_logs" ]; then
    echo "✅ Logs written to: ./smoke_logs"
    LATEST_LOG=$(ls -t ./smoke_logs/*.json 2>/dev/null | head -1)
    if [ -n "$LATEST_LOG" ]; then
        echo "   Latest log: $LATEST_LOG"
        echo ""
        echo "View results with: inspect view"
        echo "Or check the JSON: cat $LATEST_LOG | jq '.results'"
    fi
else
    echo "⚠️  No logs directory found"
fi

echo ""
echo "Expected outcomes:"
echo "  ✅ Eval completes without errors"
echo "  ✅ Transcript shows conversation with assistant"
echo "  ✅ Judge provides scores for the response"
echo ""
