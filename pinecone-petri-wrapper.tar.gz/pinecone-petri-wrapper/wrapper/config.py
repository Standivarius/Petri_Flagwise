"""Configuration management via environment variables."""
import os
from typing import Optional


class Settings:
    """Application settings loaded from environment variables."""

    # Pinecone Assistant configuration
    ASSISTANT_BASE_URL: str = os.getenv("ASSISTANT_BASE_URL", "")
    PINECONE_API_KEY: str = os.getenv("PINECONE_API_KEY", "")
    ASSISTANT_ID: Optional[str] = os.getenv("ASSISTANT_ID")
    INDEX: Optional[str] = os.getenv("INDEX")
    PROJECT: Optional[str] = os.getenv("PROJECT")

    # Wrapper authentication
    WRAPPER_TOKEN: str = os.getenv("WRAPPER_TOKEN", "change-me-in-production")

    # Server configuration
    PORT: int = int(os.getenv("PORT", "8080"))
    BIND_HOST: str = os.getenv("BIND_HOST", "127.0.0.1")  # localhost only by default

    # Timeout configuration (seconds)
    CONNECT_TIMEOUT: float = float(os.getenv("CONNECT_TIMEOUT", "10.0"))
    UPSTREAM_TIMEOUT: float = float(os.getenv("UPSTREAM_TIMEOUT", "30.0"))

    # Retry configuration
    MAX_RETRIES: int = int(os.getenv("MAX_RETRIES", "1"))

    def validate(self):
        """Validate required configuration."""
        errors = []

        if not self.ASSISTANT_BASE_URL:
            errors.append("ASSISTANT_BASE_URL is required")
        if not self.PINECONE_API_KEY:
            errors.append("PINECONE_API_KEY is required")
        if not self.WRAPPER_TOKEN or self.WRAPPER_TOKEN == "change-me-in-production":
            errors.append("WRAPPER_TOKEN must be set to a secure value")

        if errors:
            raise ValueError(f"Configuration errors: {'; '.join(errors)}")

        # Normalize base URL
        self.ASSISTANT_BASE_URL = self.ASSISTANT_BASE_URL.rstrip("/")

        print("Configuration validated successfully")
        print(f"  Assistant URL: {self.ASSISTANT_BASE_URL}")
        print(f"  Assistant ID: {self.ASSISTANT_ID or 'not set'}")
        print(f"  Index: {self.INDEX or 'not set'}")
        print(f"  Project: {self.PROJECT or 'not set'}")
        print(f"  Bind: {self.BIND_HOST}:{self.PORT}")
        print(f"  Timeouts: connect={self.CONNECT_TIMEOUT}s, upstream={self.UPSTREAM_TIMEOUT}s")
        print(f"  Max retries: {self.MAX_RETRIES}")


# Global settings instance
settings = Settings()

# Validate on import (fails fast if misconfigured)
if __name__ != "__main__":
    settings.validate()
