"""
Pinecone Assistant → OpenAI-compatible wrapper for Petri testing.
Exposes /v1/chat/completions endpoint that forwards to Pinecone Assistant API.
"""
import asyncio
import time
import uuid
from typing import Optional, List, Dict, Any
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Security, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import httpx

from config import settings
from models import (
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatCompletionChoice,
    ChatMessage,
    Usage,
    HealthResponse,
)


# Security
security = HTTPBearer()


def verify_token(credentials: HTTPAuthorizationCredentials = Security(security)) -> str:
    """Verify the wrapper authentication token."""
    if credentials.credentials != settings.WRAPPER_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid authentication token")
    return credentials.credentials


# HTTP client with connection pooling
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage HTTP client lifecycle."""
    app.state.http_client = httpx.AsyncClient(
        timeout=httpx.Timeout(
            connect=settings.CONNECT_TIMEOUT,
            read=settings.UPSTREAM_TIMEOUT,
            write=10.0,
            pool=5.0,
        ),
        limits=httpx.Limits(max_keepalive_connections=20, max_connections=100),
    )
    yield
    await app.state.http_client.aclose()


app = FastAPI(
    title="Pinecone Assistant Wrapper",
    description="OpenAI-compatible wrapper for Pinecone Assistant API",
    version="1.0.0",
    lifespan=lifespan,
)


def redact_secrets(data: Any) -> Any:
    """Recursively redact secrets from data for logging."""
    if isinstance(data, dict):
        return {
            k: "***REDACTED***" if k.lower() in ("api_key", "token", "authorization", "secret") else redact_secrets(v)
            for k, v in data.items()
        }
    elif isinstance(data, list):
        return [redact_secrets(item) for item in data]
    return data


async def call_pinecone_assistant(
    messages: List[Dict[str, str]],
    client: httpx.AsyncClient,
    request_id: str,
) -> Dict[str, Any]:
    """
    Call Pinecone Assistant API with retry logic.

    Pinecone Assistant API format (adjust based on actual API):
    POST {ASSISTANT_BASE_URL}/assistants/{ASSISTANT_ID}/chat
    Headers: {"Api-Key": PINECONE_API_KEY}
    Body: {"messages": [...]}

    Returns the assistant's response.
    """
    url = f"{settings.ASSISTANT_BASE_URL}/chat"

    # Build Pinecone request payload
    # NOTE: Adjust this based on actual Pinecone Assistant API format
    payload = {
        "messages": messages,
    }

    # Add assistant_id if configured
    if settings.ASSISTANT_ID:
        payload["assistant_id"] = settings.ASSISTANT_ID

    headers = {
        "Api-Key": settings.PINECONE_API_KEY,
        "Content-Type": "application/json",
        "X-Request-ID": request_id,
    }

    # Add optional Pinecone identifiers
    if settings.INDEX:
        headers["X-Pinecone-Index"] = settings.INDEX
    if settings.PROJECT:
        headers["X-Pinecone-Project"] = settings.PROJECT

    # Retry logic for transient failures
    max_retries = settings.MAX_RETRIES
    for attempt in range(max_retries + 1):
        try:
            print(f"[{request_id}] Calling Pinecone (attempt {attempt + 1}/{max_retries + 1})")
            start = time.time()

            response = await client.post(url, json=payload, headers=headers)

            elapsed = time.time() - start
            print(f"[{request_id}] Pinecone responded in {elapsed:.2f}s with status {response.status_code}")

            # Handle response
            if response.status_code == 200:
                return response.json()

            # Retry on 502/503 (transient errors)
            if response.status_code in (502, 503) and attempt < max_retries:
                wait_time = 2 ** attempt  # Exponential backoff
                print(f"[{request_id}] Retrying after {wait_time}s due to {response.status_code}")
                await asyncio.sleep(wait_time)
                continue

            # Other errors - fail immediately
            error_detail = response.text[:500] if response.text else "No error detail"
            print(f"[{request_id}] Pinecone error: {error_detail}")
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Pinecone Assistant error: {error_detail}",
            )

        except httpx.TimeoutException:
            if attempt < max_retries:
                wait_time = 2 ** attempt
                print(f"[{request_id}] Timeout, retrying after {wait_time}s")
                await asyncio.sleep(wait_time)
                continue
            raise HTTPException(status_code=504, detail="Pinecone Assistant timeout")

        except httpx.RequestError as e:
            if attempt < max_retries:
                wait_time = 2 ** attempt
                print(f"[{request_id}] Connection error: {e}, retrying after {wait_time}s")
                await asyncio.sleep(wait_time)
                continue
            raise HTTPException(status_code=502, detail=f"Failed to connect to Pinecone: {str(e)}")

    raise HTTPException(status_code=502, detail="Max retries exceeded")


def convert_to_openai_format(pinecone_response: Dict[str, Any], request_id: str) -> ChatCompletionResponse:
    """
    Convert Pinecone Assistant response to OpenAI chat completion format.

    Adjust based on actual Pinecone response structure.
    Common formats:
    - {"message": "...", "metadata": {...}}
    - {"response": "...", "sources": [...]}
    - {"output": "...", ...}
    """
    # Extract assistant message from Pinecone response
    # NOTE: Adjust these keys based on actual API response
    assistant_message = None

    # Try common response formats
    if "message" in pinecone_response:
        assistant_message = pinecone_response["message"]
    elif "response" in pinecone_response:
        assistant_message = pinecone_response["response"]
    elif "output" in pinecone_response:
        assistant_message = pinecone_response["output"]
    elif "text" in pinecone_response:
        assistant_message = pinecone_response["text"]
    else:
        # Fallback: stringify the whole response
        assistant_message = str(pinecone_response)
        print(f"[{request_id}] Warning: Unknown response format, using full response")

    # Build OpenAI-compatible response
    return ChatCompletionResponse(
        id=f"chatcmpl-{request_id}",
        object="chat.completion",
        created=int(time.time()),
        model="pinecone-assistant",
        choices=[
            ChatCompletionChoice(
                index=0,
                message=ChatMessage(
                    role="assistant",
                    content=assistant_message,
                ),
                finish_reason="stop",
            )
        ],
        usage=Usage(
            prompt_tokens=0,  # Pinecone doesn't provide token counts
            completion_tokens=0,
            total_tokens=0,
        ),
    )


@app.get("/healthz", response_model=HealthResponse)
async def health_check():
    """Health check endpoint."""
    return HealthResponse(status="healthy", service="pinecone-petri-wrapper")


@app.post("/v1/chat/completions", response_model=ChatCompletionResponse)
async def chat_completions(
    request: ChatCompletionRequest,
    _token: str = Depends(verify_token),
):
    """
    OpenAI-compatible chat completions endpoint.
    Forwards requests to Pinecone Assistant API.
    """
    request_id = str(uuid.uuid4())[:8]
    start_time = time.time()

    # Log request (redacted)
    print(f"\n[{request_id}] === New chat completion request ===")
    print(f"[{request_id}] Model: {request.model}")
    print(f"[{request_id}] Messages: {len(request.messages)}")
    print(f"[{request_id}] First message: {redact_secrets(request.messages[0].dict() if request.messages else {})}")

    try:
        # Convert OpenAI messages to Pinecone format
        pinecone_messages = [
            {"role": msg.role, "content": msg.content}
            for msg in request.messages
        ]

        # Call Pinecone Assistant
        pinecone_response = await call_pinecone_assistant(
            messages=pinecone_messages,
            client=app.state.http_client,
            request_id=request_id,
        )

        # Convert to OpenAI format
        openai_response = convert_to_openai_format(pinecone_response, request_id)

        elapsed = time.time() - start_time
        print(f"[{request_id}] Total request time: {elapsed:.2f}s")
        print(f"[{request_id}] Response preview: {openai_response.choices[0].message.content[:100]}...")

        return openai_response

    except HTTPException:
        raise
    except Exception as e:
        print(f"[{request_id}] Unexpected error: {e}")
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")


@app.get("/")
async def root():
    """Root endpoint with service info."""
    return {
        "service": "Pinecone Assistant → OpenAI Wrapper",
        "version": "1.0.0",
        "endpoints": {
            "health": "/healthz",
            "chat": "/v1/chat/completions (POST, requires Bearer token)",
        },
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host=settings.BIND_HOST,
        port=settings.PORT,
        log_level="info",
        access_log=True,
    )
